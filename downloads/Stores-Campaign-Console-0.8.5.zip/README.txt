افتح index.html من Chrome أو Edge على الحاسب.
اضغط اتصال بعد إدخال رمز GitHub محدوداً لمستودع stores-mobile-updates بصلاحية Contents: Read and write.
اللوحة تحمل آخر إعداد عند الاتصال، ولا تحفظ رمز النشر على القرص. الصور تحفظ بالمسودة وترفع عند النشر.
